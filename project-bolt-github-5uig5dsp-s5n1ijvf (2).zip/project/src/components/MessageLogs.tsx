import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';
import { Phone, MessageSquare, Mail, ArrowUpRight, ArrowDownLeft, Play, Clock } from 'lucide-react';

interface ConversationHistory {
  id: string;
  channel: 'vapi' | 'sms' | 'whatsapp' | 'email';
  from_role: 'ai' | 'lead';
  message: string;
  timestamp: string;
}

interface MessageLogsProps {
  leadId: string;
  campaignId: string;
}

export function MessageLogs({ leadId, campaignId }: MessageLogsProps) {
  const { user } = useAuth();
  const { theme } = useTheme();
  const [messages, setMessages] = useState<ConversationHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (leadId) {
      fetchMessages();
    }
  }, [leadId]);

  const fetchMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('conversation_history')
        .select('*')
        .eq('lead_id', leadId)
        .eq('campaign_id', campaignId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'vapi':
        return Phone;
      case 'sms':
      case 'whatsapp':
        return MessageSquare;
      case 'email':
        return Mail;
      default:
        return MessageSquare;
    }
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return 'N/A';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className={`animate-spin rounded-full h-8 w-8 border-2 border-transparent ${
          theme === 'gold'
            ? 'border-t-yellow-400'
            : 'border-t-blue-600'
        }`}></div>
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <div className="text-center py-8">
        <MessageSquare className={`h-12 w-12 mx-auto mb-4 ${
          theme === 'gold' ? 'text-gray-600' : 'text-gray-400'
        }`} />
        <p className={`text-sm ${
          theme === 'gold' ? 'text-gray-400' : 'text-gray-600'
        }`}>
          No message history yet
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h4 className={`text-sm font-medium ${
        theme === 'gold' ? 'text-gray-300' : 'text-gray-700'
      }`}>
        Message History ({messages.length})
      </h4>
      
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {messages.map((message) => {
          const Icon = getMessageIcon(message.channel);
          const isOutbound = message.from_role === 'ai';
          
          return (
            <div
              key={message.id}
              className={`p-4 rounded-lg border ${
                theme === 'gold'
                  ? 'border-yellow-400/20 bg-black/10'
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <div className={`p-1.5 rounded-lg ${
                    theme === 'gold'
                      ? isOutbound ? 'bg-yellow-400/20' : 'bg-blue-400/20'
                      : isOutbound ? 'bg-blue-100' : 'bg-green-100'
                  }`}>
                    <Icon className={`h-4 w-4 ${
                      theme === 'gold'
                        ? isOutbound ? 'text-yellow-400' : 'text-blue-400'
                        : isOutbound ? 'text-blue-600' : 'text-green-600'
                    }`} />
                  </div>
                  <span className={`text-sm font-medium capitalize ${
                    theme === 'gold' ? 'text-gray-200' : 'text-gray-900'
                  }`}>
                    {message.channel === 'vapi' ? 'call' : message.channel}
                  </span>
                  <div className="flex items-center">
                    {isOutbound ? (
                      <ArrowUpRight className={`h-3 w-3 ${
                        theme === 'gold' ? 'text-yellow-400' : 'text-blue-600'
                      }`} />
                    ) : (
                      <ArrowDownLeft className={`h-3 w-3 ${
                        theme === 'gold' ? 'text-blue-400' : 'text-green-600'
                      }`} />
                    )}
                    <span className={`text-xs ml-1 ${
                      theme === 'gold' ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      {isOutbound ? 'Sent' : 'Received'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className={`text-xs ${
                    theme === 'gold' ? 'text-gray-500' : 'text-gray-400'
                  }`}>
                    {new Date(message.timestamp).toLocaleDateString()} {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
              
              {message.message && (
                <p className={`text-sm ${
                  theme === 'gold' ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  {message.message}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}